import json
import time
import urllib.request
import urllib.parse
import urllib.error
import threading
import hashlib
from datetime import datetime, timedelta
from core.ui import Colors, print_header, print_status, print_box, pause, show_spinner

def _hash_password(password: str) -> str:
    """Retorna o hash SHA-256 da senha."""
    return hashlib.sha256(password.encode('utf-8')).hexdigest()

FIREBASE_DB_URL = "https://rastreador-c229f-default-rtdb.firebaseio.com"
DEFAULT_USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
GATEWAY_FEE = 0.50  # Taxa fixa de R$ 0,50 da MisticPay
DEFAULT_SUPPORT_WHATSAPP = "5511999999999"

DEFAULT_GATEWAY_CONFIG = {
    "client_id": "ci_e6j2m85ubnxfpcn",
    "client_secret": "cs_rnm37jkgohyiojypboku3scbu",
    "api_base_url": "https://api.misticpay.com/api"
}

_watchdog_thread = None
_watchdog_stop_event = threading.Event()

def _firebase_req(endpoint: str, method: str = "GET", data: dict = None) -> tuple:
    """Função REST para o Firebase Realtime Database."""
    url = f"{FIREBASE_DB_URL}/{endpoint.lstrip('/')}.json"
    headers = {"User-Agent": DEFAULT_USER_AGENT, "Content-Type": "application/json"}
    
    body_bytes = None
    if data is not None:
        body_bytes = json.dumps(data).encode('utf-8')

    req = urllib.request.Request(url, data=body_bytes, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=6) as response:
            res = response.read().decode('utf-8')
            return response.status, json.loads(res) if res and res != "null" else None
    except urllib.error.HTTPError as e:
        return e.code, None
    except Exception:
        return 500, None

# --- CONFIGURAÇÃO DO WHATSAPP DE SUPORTE COMERCIAL ---

def get_support_whatsapp_from_firebase() -> str:
    """Busca o número ou link do WhatsApp de suporte salvo no Firebase."""
    status, num = _firebase_req("app_config/support_whatsapp", method="GET")
    if status == 200 and isinstance(num, str) and num.strip():
        return num.strip()
    _firebase_req("app_config/support_whatsapp", method="PUT", data=DEFAULT_SUPPORT_WHATSAPP)
    return DEFAULT_SUPPORT_WHATSAPP

def save_support_whatsapp_in_firebase(number_or_link: str) -> tuple:
    """Salva o número ou link do WhatsApp de suporte no Firebase."""
    clean_num = number_or_link.strip()
    status, _ = _firebase_req("app_config/support_whatsapp", method="PUT", data=clean_num)
    if status in (200, 201):
        return True, f"WhatsApp do suporte comercial atualizado com sucesso para: {clean_num}"
    return False, f"Erro ao conectar com o servidor (HTTP {status})."

# --- DESCONEXÃO GLOBAL EM MASSA DE TODOS OS USUÁRIOS ---

def disconnect_all_users_in_firebase() -> tuple:
    """Atualiza o timestamp de reset de sessão global no Firebase para derrubar TODOS os usuários ativos."""
    reset_ts = time.time()
    status, _ = _firebase_req("app_config/global_session_reset_timestamp", method="PUT", data=reset_ts)
    if status in (200, 201):
        return True, "Todos os usuários foram desconectados do sistema com sucesso!"
    return False, f"Falha ao conectar com o servidor (HTTP {status})."

def get_global_session_reset_timestamp() -> float:
    """Busca o timestamp do último reset global de sessões."""
    status, ts = _firebase_req("app_config/global_session_reset_timestamp", method="GET")
    return float(ts) if status == 200 and ts is not None else 0.0

# --- ROBÔ DE MONITORAMENTO E DESCONEXÃO AUTOMÁTICA DE SESSÃO ---

def start_license_watchdog(username: str, session_login_ts: float = None):
    """Inicia um robô em segundo plano (Daemon Thread) que verifica a cada 8 segundos
    se a licença do usuário venceu, se foi suspensa pelo admin ou se houve reset global de sessões.
    """
    global _watchdog_thread, _watchdog_stop_event
    
    _watchdog_stop_event.set()
    if _watchdog_thread and _watchdog_thread.is_alive():
        try:
            _watchdog_thread.join(timeout=0.5)
        except Exception:
            pass
        
    _watchdog_stop_event = threading.Event()
    username_clean = username.strip().lower()
    login_ts = session_login_ts or time.time()

    def _watchdog_loop():
        failed_attempts = 0
        while not _watchdog_stop_event.is_set():
            time.sleep(8)
            if _watchdog_stop_event.is_set():
                break
            
            try:
                global_reset_ts = get_global_session_reset_timestamp()
                if global_reset_ts > login_ts:
                    _trigger_disconnect("Todos os usuários foram desconectados pelo Administrador.", username_clean)
                    break

                status, udata = _firebase_req(f"users/{username_clean}", method="GET")
                
                if status not in (200, 404):
                    failed_attempts += 1
                    if failed_attempts >= 3:
                        _trigger_disconnect("Conexão perdida repetidas vezes. Por segurança, a sessão foi encerrada.", username_clean)
                        break
                    continue
                
                failed_attempts = 0

                if status == 404 or not udata:
                    _trigger_disconnect("Sua conta foi removida pelo administrador.", username_clean)
                    break

                if not udata.get("active", True):
                    _trigger_disconnect("Sua conta foi suspensa ou bloqueada pelo administrador.", username_clean)
                    break

                exp_ts = float(udata.get("expiration_timestamp", 0))
                now_ts = time.time()
                if now_ts >= exp_ts:
                    exp_str = datetime.fromtimestamp(exp_ts).strftime("%d/%m/%Y às %H:%M")
                    _trigger_disconnect(f"Sua licença comercial expirou em {exp_str}.", username_clean)
                    break
                
                # Monitoramento de Alertas em Tempo Real (Live Alerts)
                alert_status, alert_data = _firebase_req(f"live_alerts/{username_clean}", method="GET")
                if alert_status == 200 and isinstance(alert_data, dict):
                    for alert_id, alert_info in alert_data.items():
                        if isinstance(alert_info, dict):
                            t = alert_info.get("title", "Alerta do Administrador")
                            m = alert_info.get("message", "")
                            
                            import os
                            os.system("termux-vibrate -d 500 2>/dev/null")
                            os.system('termux-toast -s "Novo Alerta Recebido" 2>/dev/null')
                            
                            print("\n\n")
                            box_txt = f"🚨 {Colors.BOLD}{t}{Colors.RESET}\n\n{m}"
                            print_box(box_txt, color=Colors.BRIGHT_MAGENTA, title="ALERTA EM TEMPO REAL")
                            print(f"{Colors.DIM}Pressione ENTER para continuar...{Colors.RESET}\n")
                            
                            _firebase_req(f"live_alerts/{username_clean}/{alert_id}", method="DELETE")
                            
                # Monitoramento de Convites de Chat Anônimo
                inv_status, inv_data = _firebase_req(f"chat_invites/{username_clean}", method="GET")
                if inv_status == 200 and isinstance(inv_data, dict):
                    status_inv = inv_data.get("status")
                    if status_inv == "PENDING":
                        sender = inv_data.get("from", "Desconhecido")
                        
                        import os
                        os.system("termux-vibrate -d 800 2>/dev/null")
                        os.system('termux-toast -s "Novo Convite de Chat!" 2>/dev/null')
                        
                        print("\n\n")
                        box_txt = (
                            f"💬 {Colors.BOLD}O usuário {Colors.BRIGHT_CYAN}{sender}{Colors.RESET}{Colors.BOLD} quer iniciar um Chat Anônimo com você!{Colors.RESET}\n\n"
                            f"👉 Para ACEITAR, digite {Colors.BRIGHT_GREEN}/aceitar{Colors.RESET} e pressione ENTER.\n"
                            f"👉 Para RECUSAR, digite {Colors.BRIGHT_RED}/negar{Colors.RESET} e pressione ENTER."
                        )
                        print_box(box_txt, color=Colors.BRIGHT_CYAN, title="CONVITE DE CHAT RECEBIDO")
                        
                        _firebase_req(f"chat_invites/{username_clean}/status", method="PUT", data="DELIVERED")
                            
            except Exception:
                pass

    def _trigger_disconnect(reason: str, user: str):
        from core.notifier import send_native_notification
        import os

        os.system("termux-vibrate -d 1000 2>/dev/null")
        os.system('termux-toast -s "Sessão Encerrada!" 2>/dev/null')
        send_native_notification("⚠️ Sessão Encerrada - Robô de Segurança", reason)

        print("\n\n")
        err_box = (
            f"⛔ {Colors.BOLD}SESSÃO ENCERRADA PELO ROBÔ DE SEGURANÇA{Colors.RESET}\n\n"
            f"Usuário: {Colors.BOLD}{user}{Colors.RESET}\n"
            f"Motivo:  {Colors.BRIGHT_RED}{reason}{Colors.RESET}\n\n"
            f"{Colors.DIM}Entre em contato com o administrador para renovar o acesso.{Colors.RESET}"
        )
        print_box(err_box, color=Colors.BRIGHT_RED, title="ROBÔ DE SEGURANÇA: DESCONECTADO")
        print("\n[ Pressione ENTER para sair ]")
        time.sleep(2)
        os._exit(0)

    _watchdog_thread = threading.Thread(target=_watchdog_loop, daemon=True)
    _watchdog_thread.start()

def stop_license_watchdog():
    """Para a execução do robô de monitoramento de sessão."""
    global _watchdog_stop_event
    _watchdog_stop_event.set()

# --- AUTENTICAÇÃO MASTER DO ADMINISTRADOR ---

def get_admin_password_from_firebase() -> str:
    """Busca a senha master do administrador salva online no servidor."""
    status, pass_val = _firebase_req("app_config/admin_auth/password", method="GET")
    if status == 200 and isinstance(pass_val, str) and pass_val.strip():
        return pass_val.strip()
    
    _firebase_req("app_config/admin_auth/password", method="PUT", data="admin123")
    return "admin123"

def verify_admin_password(entered_pass: str) -> bool:
    """Verifica a senha master informada contra o banco de dados online."""
    current_master_pass = get_admin_password_from_firebase()
    return entered_pass.strip() == current_master_pass

def change_admin_password_in_firebase(old_pass: str, new_pass: str) -> tuple:
    """Altera a senha master do administrador salvando diretamente no servidor online."""
    if not verify_admin_password(old_pass):
        return False, "Senha master atual incorreta!"
    
    if len(new_pass.strip()) < 4:
        return False, "A nova senha deve ter no mínimo 4 caracteres!"

    status, _ = _firebase_req("app_config/admin_auth/password", method="PUT", data=new_pass.strip())
    if status in (200, 201):
        return True, "Senha Master do Administrador alterada com sucesso no servidor online!"
    return False, f"Falha ao conectar com o servidor (HTTP {status})."

# --- CONFIGURAÇÃO DO GATEWAY DE PAGAMENTOS ONLINE ---

def get_cloud_gateway_config() -> dict:
    """Busca as credenciais da API salvas no servidor Firebase."""
    status, cfg = _firebase_req("app_config/gateway", method="GET")
    if status == 200 and isinstance(cfg, dict) and cfg.get("client_id"):
        return cfg
    
    _firebase_req("app_config/gateway", method="PUT", data=DEFAULT_GATEWAY_CONFIG)
    return DEFAULT_GATEWAY_CONFIG

def save_cloud_gateway_config(client_id: str, client_secret: str, api_base_url: str = None) -> bool:
    """Salva/Atualiza as credenciais da API diretamente no servidor online Firebase."""
    current = get_cloud_gateway_config()
    payload = {
        "client_id": client_id.strip(),
        "client_secret": client_secret.strip(),
        "api_base_url": (api_base_url or current.get("api_base_url", "https://api.misticpay.com/api")).strip()
    }
    status, _ = _firebase_req("app_config/gateway", method="PUT", data=payload)
    return status in (200, 201)

# --- NOTIFICAÇÕES ---

def send_user_notification(username: str, title: str, message: str) -> tuple:
    """Envia notificação individual."""
    username_clean = username.strip().lower()
    notif_id = f"notif_{int(time.time()*1000)}"
    payload = {
        "id": notif_id,
        "title": title,
        "message": message,
        "date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "read": False
    }
    status, _ = _firebase_req(f"user_notifications/{username_clean}/{notif_id}", method="PUT", data=payload)
    if status in (200, 201):
        return True, f"Notificação individual enviada com sucesso para '{username_clean}'!"
    return False, f"Erro ao enviar notificação (HTTP {status})."

def send_broadcast_notification(title: str, message: str) -> tuple:
    """Envia notificação coletiva."""
    notif_id = f"bcast_{int(time.time()*1000)}"
    payload = {
        "id": notif_id,
        "title": title,
        "message": message,
        "date": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }
    status, _ = _firebase_req(f"broadcast_notifications/{notif_id}", method="PUT", data=payload)
    if status in (200, 201):
        return True, "Notificação coletiva enviada com sucesso a todos os clientes!"
    return False, f"Erro ao enviar notificação (HTTP {status})."

def check_and_display_notifications(username: str):
    """Exibe notificações pendentes."""
    username_clean = username.strip().lower()
    from core.notifier import send_native_notification
    
    st_ind, ind_dict = _firebase_req(f"user_notifications/{username_clean}", method="GET")
    if st_ind == 200 and isinstance(ind_dict, dict):
        for n_id, n_data in ind_dict.items():
            if isinstance(n_data, dict) and not n_data.get("read", False):
                t = n_data.get("title", "Aviso do Administrador")
                m = n_data.get("message", "")
                
                box_txt = f"📢 {Colors.BOLD}{t}{Colors.RESET}\n\n{m}\n\n{Colors.DIM}Data: {n_data.get('date','')}{Colors.RESET}"
                print_box(box_txt, color=Colors.BRIGHT_YELLOW, title="NOTIFICAÇÃO DIRETA")
                send_native_notification(t, m)
                
                _firebase_req(f"user_notifications/{username_clean}/{n_id}/read", method="PUT", data=True)
                pause()

    st_bc, bc_dict = _firebase_req("broadcast_notifications", method="GET")
    if st_bc == 200 and isinstance(bc_dict, dict):
        _, seen_dict = _firebase_req(f"user_seen_broadcasts/{username_clean}", method="GET")
        seen_set = set(seen_dict.keys()) if isinstance(seen_dict, dict) else set()

        for b_id, b_data in bc_dict.items():
            if isinstance(b_data, dict) and b_id not in seen_set:
                t = b_data.get("title", "Comunicado Geral")
                m = b_data.get("message", "")
                
                box_txt = f"🌐 {Colors.BOLD}{t}{Colors.RESET}\n\n{m}\n\n{Colors.DIM}Data: {b_data.get('date','')}{Colors.RESET}"
                print_box(box_txt, color=Colors.BRIGHT_CYAN, title="COMUNICADO GERAL")
                send_native_notification(t, m)
                
                _firebase_req(f"user_seen_broadcasts/{username_clean}/{b_id}", method="PUT", data=True)
                pause()

def verify_license(username: str, password: str) -> tuple:
    """Verifica credenciais e licença no Firebase."""
    username_clean = username.strip().lower()
    if not username_clean or not password:
        return False, "Informe usuário e senha."

    status, user_data = _firebase_req(f"users/{username_clean}", method="GET")

    if status != 200 or not user_data:
        return False, "Usuário não cadastrado ou não encontrado."

    db_pass = user_data.get("password", "")
    input_pass = password.strip()
    input_hashed = _hash_password(input_pass)
    
    if db_pass != input_pass and db_pass != input_hashed:
        return False, "Senha incorreta. Verifique suas credenciais."
    elif db_pass == input_pass and db_pass != input_hashed:
        # Migração transparente para senha com hash (Segurança extra baseada no BOT WEB)
        _firebase_req(f"users/{username_clean}/password", method="PUT", data=input_hashed)

    if not user_data.get("active", True):
        return False, "Sua conta foi suspensa ou bloqueada pelo administrador."

    exp_ts = float(user_data.get("expiration_timestamp", 0))
    now_ts = time.time()

    if now_ts >= exp_ts:
        exp_date_str = datetime.fromtimestamp(exp_ts).strftime("%d/%m/%Y às %H:%M")
        return False, f"Sua licença EXPIROU em {exp_date_str}. Entre em contato para renovar."

    diff_sec = exp_ts - now_ts
    days = int(diff_sec // 86400)
    hours = int((diff_sec % 86400) // 3600)
    mins = int((diff_sec % 3600) // 60)

    time_left_str = []
    if days > 0: time_left_str.append(f"{days}d")
    if hours > 0: time_left_str.append(f"{hours}h")
    time_left_str.append(f"{mins}m")

    user_data["session_login_timestamp"] = now_ts
    user_data["time_left_formatted"] = " ".join(time_left_str)
    user_data["expiration_formatted"] = datetime.fromtimestamp(exp_ts).strftime("%d/%m/%Y %H:%M")
    user_data["balance"] = float(user_data.get("balance", 0.0))
    user_data["total_deposited"] = float(user_data.get("total_deposited", 0.0))
    user_data["total_withdrawn"] = float(user_data.get("total_withdrawn", 0.0))
    user_data["role"] = user_data.get("role", "user")
    
    return True, user_data

def update_user_version_in_firebase(username: str, version: str):
    """Registra a versão do aplicativo instalada no celular do usuário no Firebase."""
    username_clean = username.strip().lower()
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    _firebase_req(f"users/{username_clean}/installed_version", method="PUT", data=version.strip())
    _firebase_req(f"users/{username_clean}/last_login_date", method="PUT", data=now_str)

def show_user_profile(username: str):
    """Exibe o perfil e saldo do usuário."""
    print_header("Meu Saldo & Perfil", "Dados da Sua Conta")
    
    username_clean = username.strip().lower()
    status, udata = _firebase_req(f"users/{username_clean}", method="GET")

    if status != 200 or not udata:
        print_status("Erro ao carregar dados do seu perfil.", "error")
        pause()
        return

    bal = float(udata.get("balance", 0.0))
    deposited = float(udata.get("total_deposited", 0.0))
    withdrawn = float(udata.get("total_withdrawn", 0.0))
    role_str = "ADMINISTRADOR MASTER" if udata.get("role") == "admin" else "CLIENTE"
    
    exp_ts = float(udata.get("expiration_timestamp", 0))
    now_ts = time.time()
    diff_sec = max(0, exp_ts - now_ts)
    days = int(diff_sec // 86400)
    hours = int((diff_sec % 86400) // 3600)

    time_left_str = []
    if days > 0: time_left_str.append(f"{days}d")
    if hours > 0: time_left_str.append(f"{hours}h")
    time_left_str.append(f"{int((diff_sec % 3600) // 60)}m")
    
    exp_date_str = datetime.fromtimestamp(exp_ts).strftime("%d/%m/%Y às %H:%M")
    is_blocked = not udata.get("active", True)
    is_expired = now_ts >= exp_ts

    if is_blocked:
        st_text = "BLOQUEADO"
        st_color = Colors.BRIGHT_RED
    elif is_expired:
        st_text = "EXPIRADO"
        st_color = Colors.BRIGHT_RED
    else:
        st_text = "ATIVA / VÁLIDA"
        st_color = Colors.BRIGHT_GREEN

    content = (
        f"👤 Usuário:          {Colors.BOLD}{Colors.BRIGHT_WHITE}{username_clean}{Colors.RESET} ({role_str})\n"
        f"💰 Saldo Disponível: {Colors.BRIGHT_GREEN}{Colors.BOLD}R$ {bal:.2f}{Colors.RESET}\n"
        f"📥 Total Depositado: {Colors.BRIGHT_CYAN}R$ {deposited:.2f}{Colors.RESET}\n"
        f"📤 Total Sacado:     {Colors.BRIGHT_YELLOW}R$ {withdrawn:.2f}{Colors.RESET}\n"
        f"🏷️ Taxa Gateway:     {Colors.DIM}R$ 0,50 (Fixa por depósito){Colors.RESET}\n"
        f"{'─' * 45}\n"
        f"✔️ Status Licença:   {st_color}{st_text}{Colors.RESET}\n"
        f"⏳ Tempo Restante:   {Colors.BRIGHT_GREEN}{' '.join(time_left_str) if not is_expired else 'Expirado'}{Colors.RESET}\n"
        f"📅 Data Expiração:   {exp_date_str}"
    )
    print_box(content, color=Colors.BRIGHT_GREEN, title=f"PERFIL DA CONTA: {username_clean.upper()}")
    pause()

def calculate_expiration(amount: int, unit: str) -> float:
    now = datetime.now()
    if unit == "MINUTOS": dt = now + timedelta(minutes=amount)
    elif unit == "HORAS": dt = now + timedelta(hours=amount)
    elif unit == "DIAS": dt = now + timedelta(days=amount)
    elif unit == "SEMANAS": dt = now + timedelta(weeks=amount)
    elif unit == "MESES": dt = now + timedelta(days=amount * 30)
    else: dt = now + timedelta(days=amount)
    return dt.timestamp()

def register_user_in_firebase(username: str, password: str, duration_amount: int, duration_unit: str, role: str = "user") -> tuple:
    username_clean = username.strip().lower()
    exp_ts = calculate_expiration(duration_amount, duration_unit.upper())
    exp_formatted = datetime.fromtimestamp(exp_ts).strftime("%d/%m/%Y %H:%M:%S")

    _, existing = _firebase_req(f"users/{username_clean}", method="GET")
    existing_balance = float(existing.get("balance", 0.0)) if existing else 0.0
    existing_deposited = float(existing.get("total_deposited", 0.0)) if existing else 0.0
    existing_withdrawn = float(existing.get("total_withdrawn", 0.0)) if existing else 0.0

    existing_ver = existing.get("installed_version") if (existing and isinstance(existing, dict)) else None
    if not existing_ver:
        from core.updater import get_current_app_version
        existing_ver = get_current_app_version()

    user_payload = {
        "username": username_clean,
        "password": _hash_password(password.strip()),
        "role": role.strip().lower(),
        "balance": existing_balance,
        "total_deposited": existing_deposited,
        "total_withdrawn": existing_withdrawn,
        "installed_version": existing_ver,
        "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "expiration_timestamp": exp_ts,
        "expiration_date": exp_formatted,
        "duration_amount": duration_amount,
        "duration_unit": duration_unit.upper(),
        "active": True
    }

    status, resp = _firebase_req(f"users/{username_clean}", method="PUT", data=user_payload)
    if status in (200, 201):
        return True, f"Usuário '{username_clean}' ({role.upper()}) criado/atualizado com sucesso!"
    return False, f"Erro no servidor (HTTP {status})."

def get_user_balance_from_firebase(username: str) -> float:
    username_clean = username.strip().lower()
    status, bal = _firebase_req(f"users/{username_clean}/balance", method="GET")
    return float(bal) if status == 200 and bal is not None else 0.0

def credit_user_balance_in_firebase(username: str, gross_amount: float) -> tuple:
    """Credita o valor líquido no saldo do usuário."""
    username_clean = username.strip().lower()
    net_amount = max(0.0, gross_amount - GATEWAY_FEE)

    status, udata = _firebase_req(f"users/{username_clean}", method="GET")
    if status != 200 or not udata:
        return False, "Usuário não encontrado.", 0.0

    current_bal = float(udata.get("balance", 0.0))
    current_dep = float(udata.get("total_deposited", 0.0))

    new_bal = current_bal + net_amount
    new_dep = current_dep + gross_amount

    _firebase_req(f"users/{username_clean}/balance", method="PUT", data=new_bal)
    _firebase_req(f"users/{username_clean}/total_deposited", method="PUT", data=new_dep)

    tx_entry = {
        "type": "DEPOSITO_PIX",
        "gross_amount": gross_amount,
        "fee": GATEWAY_FEE,
        "net_amount": net_amount,
        "date": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }
    _firebase_req(f"user_transactions/{username_clean}", method="POST", data=tx_entry)

    return True, f"Creditado R$ {net_amount:.2f} (Taxa Gateway: R$ 0,50).", new_bal

def deduct_user_balance_in_firebase(username: str, amount: float) -> tuple:
    """Subtrai o saldo do usuário SOMENTE QUANDO O SAQUE FOR EFETIVADO COM SUCESSO."""
    username_clean = username.strip().lower()
    status, udata = _firebase_req(f"users/{username_clean}", method="GET")
    if status != 200 or not udata:
        return False, "Usuário não encontrado no servidor.", 0.0

    current_bal = float(udata.get("balance", 0.0))
    current_withdrawn = float(udata.get("total_withdrawn", 0.0))

    if amount > current_bal:
        return False, f"Saldo insuficiente no momento! Saldo atual: R$ {current_bal:.2f}", current_bal

    new_bal = max(0.0, current_bal - amount)
    new_withdrawn = current_withdrawn + amount

    _firebase_req(f"users/{username_clean}/balance", method="PUT", data=new_bal)
    _firebase_req(f"users/{username_clean}/total_withdrawn", method="PUT", data=new_withdrawn)

    tx_entry = {
        "type": "SAQUE_EFETIVADO",
        "amount": amount,
        "date": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }
    _firebase_req(f"user_transactions/{username_clean}", method="POST", data=tx_entry)

    return True, "Saldo debitado com sucesso.", new_bal

def reserve_user_balance_for_withdrawal(username: str, amount: float) -> tuple:
    """Verifica se o usuário possui saldo suficiente sem debitar a conta."""
    username_clean = username.strip().lower()
    status, udata = _firebase_req(f"users/{username_clean}", method="GET")
    if status != 200 or not udata:
        return False, "Usuário não encontrado.", 0.0

    current_bal = float(udata.get("balance", 0.0))
    if amount > current_bal:
        return False, f"Saldo insuficiente! Saldo atual: R$ {current_bal:.2f}", current_bal

    return True, "Saldo verificado.", current_bal

def refund_user_balance_in_firebase(username: str, amount: float) -> float:
    """Retorna o saldo atual do usuário."""
    return get_user_balance_from_firebase(username)

def get_all_users_from_firebase() -> list:
    status, users_dict = _firebase_req("users", method="GET")
    if status != 200 or not users_dict:
        return []

    now_ts = time.time()
    result = []
    for uname, udata in users_dict.items():
        if isinstance(udata, dict):
            exp_ts = float(udata.get("expiration_timestamp", 0))
            is_blocked = not udata.get("active", True)
            is_expired = now_ts >= exp_ts
            
            diff_sec = max(0, exp_ts - now_ts)
            days = int(diff_sec // 86400)
            hours = int((diff_sec % 86400) // 3600)

            if is_blocked:
                udata["status_label"] = "BLOQUEADO"
                udata["remaining_str"] = "Bloqueado"
            elif is_expired:
                udata["status_label"] = "EXPIRADO"
                udata["remaining_str"] = "Expirado"
            else:
                udata["status_label"] = "ATIVO"
                udata["remaining_str"] = f"{days}d {hours}h"

            udata["balance"] = float(udata.get("balance", 0.0))
            udata["role"] = udata.get("role", "user")
            result.append(udata)
    return result

def toggle_user_status_in_firebase(username: str, active_state: bool) -> bool:
    username_clean = username.strip().lower()
    status, _ = _firebase_req(f"users/{username_clean}/active", method="PUT", data=active_state)
    return status == 200

def delete_user_from_firebase(username: str) -> bool:
    username_clean = username.strip().lower()
    status, _ = _firebase_req(f"users/{username_clean}", method="DELETE")
    return status == 200
