import os
import sys
import json
import time
import zipfile
import tempfile
import shutil
import urllib.request
import urllib.parse
import urllib.error
import re

FIREBASE_DB_URL = "https://rastreador-c229f-default-rtdb.firebaseio.com"
DEFAULT_USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"

BASE_DIR = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
CONFIG_FILE = os.path.join(BASE_DIR, "config.json")
INSTALLED_UPDATE_FILE = os.path.join(BASE_DIR, ".installed_update.json")

def get_current_app_version() -> str:
    """Lê a versão atual instalada no aplicativo a partir de .installed_update.json ou config.json."""
    if os.path.exists(INSTALLED_UPDATE_FILE):
        try:
            with open(INSTALLED_UPDATE_FILE, "r", encoding="utf-8") as f:
                fp = json.load(f)
                if fp and fp.get("version"):
                    return str(fp.get("version")).strip()
        except Exception:
            pass

    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                cfg = json.load(f)
                if cfg and cfg.get("version"):
                    return str(cfg.get("version")).strip()
        except Exception:
            pass
    return "6.6.0"

def get_installed_update_fingerprint() -> dict:
    """Lê o registro da última atualização instalada pelo usuário no dispositivo."""
    if os.path.exists(INSTALLED_UPDATE_FILE):
        try:
            with open(INSTALLED_UPDATE_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return {}

def save_installed_update_fingerprint(version: str, download_url: str):
    """Grava o registro e assinatura da atualização recém-instalada no dispositivo."""
    clean_url = normalize_direct_download_url(download_url)
    payload = {
        "version": version.strip(),
        "download_url": clean_url,
        "installed_at": time.time(),
        "date_formatted": time.strftime("%Y-%m-%d %H:%M:%S")
    }
    try:
        with open(INSTALLED_UPDATE_FILE, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2)
    except Exception:
        pass

    # Atualiza o arquivo config.json local com a nova versão instalada
    try:
        cfg = {}
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                cfg = json.load(f)
        cfg["version"] = version.strip()
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(cfg, f, indent=2)
    except Exception:
        pass

def _version_tuple(v_str: str) -> tuple:
    """Converte string de versão em tupla comparável de inteiros (sempre 3 elementos)."""
    try:
        clean_v = re.sub(r'[^0-9.]', '', str(v_str))
        if not clean_v:
            return (0, 0, 0)
        parts = list(map(int, clean_v.split('.')))
        while len(parts) < 3:
            parts.append(0)
        return tuple(parts[:3])
    except Exception:
        return (0, 0, 0)

def normalize_direct_download_url(url: str) -> str:
    """Converte automaticamente URLs de serviços de hospedagem (Pixeldrain, Dropbox, Google Drive)
    para links de download direto de arquivos binários .zip.
    """
    clean_url = url.strip()

    pix_match = re.search(r'pixeldrain\.com/u/([a-zA-Z0-9]+)', clean_url)
    if pix_match:
        file_id = pix_match.group(1)
        return f"https://pixeldrain.com/api/file/{file_id}?download"

    if "dropbox.com" in clean_url and "dl=0" in clean_url:
        return clean_url.replace("dl=0", "dl=1")

    gdrive_match = re.search(r'drive\.google\.com/file/d/([a-zA-Z0-9_-]+)', clean_url)
    if gdrive_match:
        file_id = gdrive_match.group(1)
        return f"https://drive.google.com/uc?export=download&id={file_id}"

    return clean_url

def check_for_updates() -> tuple:
    """Consulta no Firebase se há uma versão estritamente MAIOR e não instalada no dispositivo."""
    url = f"{FIREBASE_DB_URL}/system_update.json"
    req = urllib.request.Request(url, headers={"User-Agent": DEFAULT_USER_AGENT})
    current_ver = get_current_app_version()
    installed_fp = get_installed_update_fingerprint()

    try:
        with urllib.request.urlopen(req, timeout=6) as resp:
            data_str = resp.read().decode('utf-8')
            if not data_str or data_str == "null":
                return False, "Nenhuma atualização disponível no servidor.", None

            data = json.loads(data_str)
            remote_ver = str(data.get("version", current_ver)).strip()
            zip_url = data.get("download_url", "")
            changelog = data.get("changelog", "Melhorias gerais e correções de segurança.")

            direct_url = normalize_direct_download_url(zip_url)

            # 1. Checa se este link/pacote exato já foi baixado e instalado neste celular
            if installed_fp:
                inst_url = installed_fp.get("download_url", "")
                inst_ver = installed_fp.get("version", "")

                if inst_url and inst_url.strip() == direct_url.strip():
                    return False, f"Seu sistema já baixou e instalou este pacote de atualização.", None

                if inst_ver and _version_tuple(remote_ver) <= _version_tuple(inst_ver):
                    return False, f"Seu sistema já está na versão v{inst_ver}.", None

            # 2. Checa versão local contra a versão remota
            if _version_tuple(remote_ver) > _version_tuple(current_ver) and direct_url:
                return True, f"Nova versão v{remote_ver} disponível!", {
                    "version": remote_ver,
                    "download_url": direct_url,
                    "changelog": changelog
                }

            return False, f"Seu sistema já está na versão mais recente (v{current_ver}).", None
    except Exception as e:
        return False, f"Falha ao checar atualizações no servidor: {e}", None

def get_active_update_info() -> dict:
    """Busca as informações detalhadas da atualização ativa cadastrada no servidor."""
    url = f"{FIREBASE_DB_URL}/system_update.json"
    req = urllib.request.Request(url, headers={"User-Agent": DEFAULT_USER_AGENT})
    try:
        with urllib.request.urlopen(req, timeout=6) as resp:
            data_str = resp.read().decode('utf-8')
            if data_str and data_str != "null":
                return json.loads(data_str)
    except Exception:
        pass
    return None

def delete_active_update_from_firebase() -> tuple:
    """Apaga/remove a atualização ativa do servidor Firebase."""
    url = f"{FIREBASE_DB_URL}/system_update.json"
    req = urllib.request.Request(url, headers={"User-Agent": DEFAULT_USER_AGENT}, method="DELETE")
    try:
        with urllib.request.urlopen(req, timeout=6) as resp:
            return True, "Atualização removida com sucesso do servidor!"
    except Exception as e:
        return False, f"Falha ao excluir atualização no servidor: {e}"

def get_update_user_statistics() -> dict:
    """Consulta todos os usuários e calcula o total de clientes com o sistema ATUALIZADO vs DESATUALIZADO."""
    active_upd = get_active_update_info()
    if active_upd and active_upd.get("version"):
        target_ver = str(active_upd.get("version")).strip()
    else:
        target_ver = get_current_app_version()

    target_tuple = _version_tuple(target_ver)

    url_users = f"{FIREBASE_DB_URL}/users.json"
    req = urllib.request.Request(url_users, headers={"User-Agent": DEFAULT_USER_AGENT})

    try:
        with urllib.request.urlopen(req, timeout=6) as resp:
            data_str = resp.read().decode('utf-8')
            users_dict = json.loads(data_str) if data_str and data_str != "null" else {}

            total_users = len(users_dict)
            updated_count = 0
            outdated_count = 0
            user_list = []

            for uname, udata in users_dict.items():
                if isinstance(udata, dict):
                    user_ver = str(udata.get("installed_version") or "").strip()
                    if not user_ver:
                        user_ver = target_ver
                        # Auto-sincroniza no Firebase para usuários legados sem versão gravada
                        from core.auth import _firebase_req
                        _firebase_req(f"users/{uname}/installed_version", method="PUT", data=user_ver)

                    u_tuple = _version_tuple(user_ver)

                    is_updated = u_tuple >= target_tuple
                    if is_updated:
                        updated_count += 1
                        st_label = "ATUALIZADO ✔️"
                    else:
                        outdated_count += 1
                        st_label = "DESATUALIZADO ⚠️"

                    user_list.append({
                        "username": uname,
                        "installed_version": user_ver,
                        "is_updated": is_updated,
                        "status_label": st_label,
                        "last_login": udata.get("last_login_date", "Desconhecido")
                    })

            return {
                "target_version": target_ver,
                "total_users": total_users,
                "updated_count": updated_count,
                "outdated_count": outdated_count,
                "users": user_list
            }
    except Exception as e:
        return {
            "target_version": target_ver,
            "total_users": 0,
            "updated_count": 0,
            "outdated_count": 0,
            "users": [],
            "error": str(e)
        }

def run_update_flow():
    """Baixa o arquivo ZIP de atualização, extrai no projeto e reinicia o aplicativo.
    Salva a assinatura do arquivo baixado para impedir repetição de avisos no login.
    """
    from core.ui import Colors, clear_screen, print_header, print_status, print_box, prompt_input, pause, show_spinner
    from core.banner import get_anonymous_bank_banner

    clear_screen()
    print(get_anonymous_bank_banner())
    print_header("Atualizador de Sistema", "Busca de pacote ZIP no Servidor")

    show_spinner("Checando disponibilidade de atualizações no Servidor...", duration=0.8)
    has_update, msg, update_info = check_for_updates()

    if not has_update or not update_info:
        print_status(msg, "warning" if "já está" in msg or "instalou" in msg else "error")
        pause()
        return

    print_box(
        f"🚀 Nova Versão Encontrada: {Colors.BOLD}v{update_info['version']}{Colors.RESET}\n"
        f"🔗 Pacote ZIP: {Colors.CYAN}{update_info['download_url']}{Colors.RESET}\n"
        f"📝 Novidades: {update_info['changelog']}",
        color=Colors.BRIGHT_GREEN,
        title="ATUALIZAÇÃO DISPONÍVEL"
    )

    ans = prompt_input("Deseja baixar, extrair e instalar agora? (SIM/NAO)", default="SIM").upper()
    if ans != "SIM":
        print_status("Instalação de atualização cancelada.", "warning")
        pause()
        return

    tmp_dir = tempfile.mkdtemp()
    zip_path = os.path.join(tmp_dir, "update_package.zip")

    try:
        show_spinner("Baixando pacote ZIP de atualização...", duration=1.2)
        dl_url = normalize_direct_download_url(update_info['download_url'])

        req = urllib.request.Request(dl_url, headers={"User-Agent": DEFAULT_USER_AGENT})
        with urllib.request.urlopen(req, timeout=15) as resp, open(zip_path, 'wb') as out_file:
            shutil.copyfileobj(resp, out_file)

        print_status("Download concluído com sucesso!", "success")

        if not zipfile.is_zipfile(zip_path):
            raise ValueError("O link baixado retornou HTML em vez de um arquivo .ZIP binário válido. Certifique-se de usar um link de download direto.")

        show_spinner("Extraindo arquivos e atualizando a instalação...", duration=1.0)
        extract_tmp = os.path.join(tmp_dir, "extracted")
        os.makedirs(extract_tmp, exist_ok=True)

        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(extract_tmp)

        top_items = os.listdir(extract_tmp)
        source_dir = extract_tmp
        if len(top_items) == 1 and os.path.isdir(os.path.join(extract_tmp, top_items[0])):
            source_dir = os.path.join(extract_tmp, top_items[0])

        for item in os.listdir(source_dir):
            s_item = os.path.join(source_dir, item)
            d_item = os.path.join(BASE_DIR, item)
            if os.path.isdir(s_item):
                shutil.copytree(s_item, d_item, dirs_exist_ok=True)
            else:
                shutil.copy2(s_item, d_item)

        # Salva o registro da atualização instalada para bloquear avisos repetidos
        save_installed_update_fingerprint(update_info['version'], update_info['download_url'])

        print_status("Arquivos atualizados com sucesso!", "success")
        shutil.rmtree(tmp_dir, ignore_errors=True)

        print_box("🎉 Sistema Atualizado com Sucesso!\nO aplicativo será reiniciado em instantes.", color=Colors.BRIGHT_GREEN, title="INSTALAÇÃO CONCLUÍDA")
        time.sleep(1.5)
        
        python_executable = sys.executable
        os.execv(python_executable, [python_executable] + sys.argv)

    except Exception as e:
        shutil.rmtree(tmp_dir, ignore_errors=True)
        print_status(f"Falha durante a instalação da atualização: {e}", "error")
        pause()

def publish_update_to_firebase(version: str, download_url: str, changelog: str) -> tuple:
    """Publica os dados de um arquivo ZIP de atualização no Firebase convertendo automaticamente para link direto."""
    direct_url = normalize_direct_download_url(download_url)

    payload = {
        "version": version.strip(),
        "download_url": direct_url,
        "changelog": changelog.strip(),
        "published_at": time.strftime("%Y-%m-%d %H:%M:%S")
    }

    url = f"{FIREBASE_DB_URL}/system_update.json"
    req_bytes = json.dumps(payload).encode('utf-8')
    req = urllib.request.Request(url, data=req_bytes, headers={"Content-Type": "application/json", "User-Agent": DEFAULT_USER_AGENT}, method="PUT")
    
    try:
        with urllib.request.urlopen(req, timeout=6) as resp:
            return True, f"Atualização v{version} publicada com sucesso no servidor!\nURL Direta Configurada: {direct_url}"
    except Exception as e:
        return False, f"Erro ao publicar atualização no Firebase: {e}"
