import sys

def render_qr_code(text: str) -> str:
    """Renderiza QR Code compacto e responsivo usando meias-quadras Unicode (Half-Blocks).
    Reduz a largura e altura em 50%, permitindo caber perfeitamente em telas mobile.
    """
    try:
        import qrcode
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=1,
            border=1
        )
        qr.add_data(text)
        qr.make(fit=True)
        matrix = qr.get_matrix()

        height = len(matrix)
        width = len(matrix[0]) if height > 0 else 0
        lines = []

        # Processa 2 linhas por caractere de altura
        for r in range(0, height, 2):
            line = ""
            for c in range(width):
                top = matrix[r][c]
                bot = matrix[r + 1][c] if (r + 1 < height) else False

                if top and bot:
                    line += "█"
                elif top and not bot:
                    line += "▀"
                elif not top and bot:
                    line += "▄"
                else:
                    line += " "
            lines.append("  " + line)
        return "\n".join(lines)
    except ImportError:
        return "[ Instale 'pip install qrcode' para visualizar o QR Code compacto no terminal ]"
    except Exception as e:
        return f"[ QR Code indisponível: {e} ]"
