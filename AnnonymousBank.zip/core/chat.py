import sys
import time
import threading
from core.ui import Colors, clear_screen, print_header, print_status, prompt_input, pause
from core.auth import _firebase_req
from core.banner import get_anonymous_bank_banner

def run_anonymous_chat(current_username: str):
    """Abre uma sessão de chat anônimo em tempo real com outro usuário."""
    clear_screen()
    print(get_anonymous_bank_banner())
    print_header("Chat Anônimo e Seguro", "Mensageria P2P Temporária")

    target_user = prompt_input("Digite o Usuário/ID da pessoa que deseja conversar (ou 0 para Voltar)")
    if not target_user or target_user == "0":
        return

    target_user = target_user.strip().lower()
    current_username = current_username.strip().lower()

    if target_user == current_username:
        print_status("Você não pode abrir um chat com você mesmo.", "error")
        pause()
        return

    # O room ID é formado pelos dois usernames ordenados alfabeticamente para ser bidirecional
    users = sorted([current_username, target_user])
    room_id = f"{users[0]}_{users[1]}"
    chat_path = f"active_chats/{room_id}"

    clear_screen()
    print(f"{Colors.BRIGHT_MAGENTA}================================================={Colors.RESET}")
    print(f" 🔒 {Colors.BOLD}SESSÃO DE CHAT ANÔNIMO{Colors.RESET}")
    print(f" Conversando com: {Colors.BRIGHT_GREEN}{target_user}{Colors.RESET}")
    print(f" {Colors.DIM}Todas as mensagens serão apagadas ao digitar /sair{Colors.RESET}")
    print(f"{Colors.BRIGHT_MAGENTA}================================================={Colors.RESET}\n")

    stop_event = threading.Event()
    last_timestamp = 0

    def chat_monitor():
        nonlocal last_timestamp
        while not stop_event.is_set():
            status, messages = _firebase_req(chat_path, method="GET")
            if status == 200 and isinstance(messages, dict):
                # Order by timestamp
                sorted_msgs = sorted(messages.values(), key=lambda x: x.get("timestamp", 0))
                for msg in sorted_msgs:
                    msg_ts = msg.get("timestamp", 0)
                    if msg_ts > last_timestamp:
                        sender = msg.get("sender", "Unknown")
                        text = msg.get("text", "")
                        
                        # Apaga a linha atual do input, imprime a mensagem, e reescreve o input
                        sys.stdout.write("\033[2K\033[1G") 
                        if sender == current_username:
                            print(f"{Colors.BRIGHT_GREEN}[Você]{Colors.RESET}: {text}")
                        else:
                            print(f"{Colors.BRIGHT_CYAN}[{sender}]{Colors.RESET}: {text}")
                        
                        sys.stdout.write(f"\r{Colors.BRIGHT_WHITE}Você:{Colors.RESET} ")
                        sys.stdout.flush()
                        last_timestamp = msg_ts
            time.sleep(1.5)

    monitor_thread = threading.Thread(target=chat_monitor, daemon=True)
    monitor_thread.start()

    sys.stdout.write(f"\r{Colors.BRIGHT_WHITE}Você:{Colors.RESET} ")
    sys.stdout.flush()

    try:
        while True:
            text = input()
            
            if text.strip().lower() == "/sair":
                break
                
            if text.strip():
                sys.stdout.write("\033[1A\033[2K\033[1G") # Remove a linha que o usuário acabou de dar enter
                msg_id = f"msg_{int(time.time()*1000)}"
                payload = {
                    "sender": current_username,
                    "text": text.strip(),
                    "timestamp": time.time()
                }
                _firebase_req(f"{chat_path}/{msg_id}", method="PUT", data=payload)
                sys.stdout.write(f"\r{Colors.BRIGHT_WHITE}Você:{Colors.RESET} ")
                sys.stdout.flush()
            else:
                sys.stdout.write("\033[1A\033[2K\033[1G") 
                sys.stdout.write(f"\r{Colors.BRIGHT_WHITE}Você:{Colors.RESET} ")
                sys.stdout.flush()
                
    except KeyboardInterrupt:
        pass

    stop_event.set()
    monitor_thread.join(timeout=2)
    
    # Destrói o chat
    print(f"\n\n{Colors.BRIGHT_RED}Encerrando chat e apagando rastros...{Colors.RESET}")
    _firebase_req(chat_path, method="DELETE")
    time.sleep(1)
    print_status("Chat anônimo encerrado com segurança.", "success")
    pause()
