import sys
import time
import threading
from core.ui import Colors, clear_screen, print_header, print_status, prompt_input, pause, show_spinner
from core.auth import _firebase_req
from core.banner import get_anonymous_bank_banner

def run_anonymous_chat(current_username: str):
    """Solicita a criação de um chat anônimo enviando um convite."""
    clear_screen()
    print(get_anonymous_bank_banner())
    print_header("Chat Anônimo e Seguro", "Mensageria P2P Temporária")

    target_user = prompt_input("Digite o Usuário/ID da pessoa que deseja conversar (ou 0 para Voltar)")
    if not target_user or target_user == "0":
        return

    target_user = target_user.strip().lower()
    current_username = current_username.strip().lower()

    if target_user == current_username:
        print_status("Você não pode abrir um chat com você mesmo.", "error")
        pause()
        return

    # Envia convite
    invite_path = f"chat_invites/{target_user}"
    payload = {
        "from": current_username,
        "status": "PENDING",
        "timestamp": time.time()
    }
    
    show_spinner(f"Enviando convite para {target_user}...", duration=1.0)
    status, _ = _firebase_req(invite_path, method="PUT", data=payload)
    if status not in (200, 201):
        print_status(f"Falha ao enviar convite para o usuário {target_user}.", "error")
        pause()
        return

    print_status(f"Convite enviado para {target_user}! Aguardando resposta...", "info")
    print(f"{Colors.DIM}Pressione CTRL+C a qualquer momento para cancelar o convite.{Colors.RESET}\n")

    try:
        while True:
            # Polling status
            st, data = _firebase_req(invite_path, method="GET")
            if st == 200 and isinstance(data, dict):
                invite_status = data.get("status", "PENDING")
                if invite_status == "ACCEPTED":
                    _firebase_req(invite_path, method="DELETE")
                    return run_anonymous_chat_room(current_username, target_user)
                elif invite_status == "DENIED":
                    _firebase_req(invite_path, method="DELETE")
                    print_status(f"O usuário {target_user} recusou o seu convite de chat.", "error")
                    pause()
                    return
            time.sleep(2)
    except KeyboardInterrupt:
        _firebase_req(invite_path, method="DELETE")
        print(f"\n{Colors.BRIGHT_YELLOW}Convite cancelado.{Colors.RESET}")
        pause()

def run_anonymous_chat_room(current_username: str, target_user: str):
    """Loop interno da sala de chat (utilizado tanto pelo solicitante quanto pelo convidado)."""
    users = sorted([current_username, target_user])
    room_id = f"{users[0]}_{users[1]}"
    chat_path = f"active_chats/{room_id}"

    clear_screen()
    print(f"{Colors.BRIGHT_MAGENTA}================================================={Colors.RESET}")
    print(f" 🔒 {Colors.BOLD}SESSÃO DE CHAT ANÔNIMO{Colors.RESET}")
    print(f" Conversando com: {Colors.BRIGHT_GREEN}{target_user}{Colors.RESET}")
    print(f" {Colors.DIM}Todas as mensagens serão apagadas ao digitar /sair{Colors.RESET}")
    print(f"{Colors.BRIGHT_MAGENTA}================================================={Colors.RESET}\n")

    stop_event = threading.Event()
    last_timestamp = 0

    def chat_monitor():
        nonlocal last_timestamp
        while not stop_event.is_set():
            status, messages = _firebase_req(chat_path, method="GET")
            # Se o nó sumiu repentinamente, o outro encerrou
            if status != 200 or not messages:
                if last_timestamp > 0: # Só encerra se já teve mensagens
                    print(f"\n\n{Colors.BRIGHT_RED}O outro usuário encerrou o chat. Pressione ENTER para sair.{Colors.RESET}")
                    stop_event.set()
                    break

            if status == 200 and isinstance(messages, dict):
                sorted_msgs = sorted(messages.values(), key=lambda x: x.get("timestamp", 0))
                for msg in sorted_msgs:
                    msg_ts = msg.get("timestamp", 0)
                    if msg_ts > last_timestamp:
                        sender = msg.get("sender", "Unknown")
                        text = msg.get("text", "")
                        
                        sys.stdout.write("\033[2K\033[1G") 
                        if sender == current_username:
                            print(f"{Colors.BRIGHT_GREEN}[Você]{Colors.RESET}: {text}")
                        else:
                            print(f"{Colors.BRIGHT_CYAN}[{sender}]{Colors.RESET}: {text}")
                        
                        sys.stdout.write(f"\r{Colors.BRIGHT_WHITE}Você:{Colors.RESET} ")
                        sys.stdout.flush()
                        last_timestamp = msg_ts
            time.sleep(1.5)

    monitor_thread = threading.Thread(target=chat_monitor, daemon=True)
    monitor_thread.start()

    sys.stdout.write(f"\r{Colors.BRIGHT_WHITE}Você:{Colors.RESET} ")
    sys.stdout.flush()

    try:
        while not stop_event.is_set():
            text = input()
            
            if text.strip().lower() == "/sair" or stop_event.is_set():
                break
                
            if text.strip():
                sys.stdout.write("\033[1A\033[2K\033[1G") 
                msg_id = f"msg_{int(time.time()*1000)}"
                payload = {
                    "sender": current_username,
                    "text": text.strip(),
                    "timestamp": time.time()
                }
                _firebase_req(f"{chat_path}/{msg_id}", method="PUT", data=payload)
                sys.stdout.write(f"\r{Colors.BRIGHT_WHITE}Você:{Colors.RESET} ")
                sys.stdout.flush()
            else:
                sys.stdout.write("\033[1A\033[2K\033[1G") 
                sys.stdout.write(f"\r{Colors.BRIGHT_WHITE}Você:{Colors.RESET} ")
                sys.stdout.flush()
                
    except KeyboardInterrupt:
        pass

    stop_event.set()
    
    print(f"\n\n{Colors.BRIGHT_RED}Encerrando chat e apagando rastros...{Colors.RESET}")
    _firebase_req(chat_path, method="DELETE")
    time.sleep(1)
    print_status("Chat anônimo encerrado com segurança.", "success")
    pause()
