import json
import uuid
import time
import urllib.request
from datetime import datetime
from core.auth import (
    _firebase_req,
    get_user_balance_from_firebase,
    deduct_user_balance_in_firebase,
    reserve_user_balance_for_withdrawal
)

DEFAULT_USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"

DEFAULT_AUTO_PAYOUT_CONFIG = {
    "enabled": True,
    "min_limit": 5.00  # Valor mínimo em R$ para o robô aprovar automaticamente
}

def get_auto_payout_config() -> dict:
    """Busca as configurações do Robô de Saque Automático no Firebase."""
    status, cfg = _firebase_req("app_config/auto_payout", method="GET")
    if status == 200 and isinstance(cfg, dict) and "enabled" in cfg:
        return cfg
    
    _firebase_req("app_config/auto_payout", method="PUT", data=DEFAULT_AUTO_PAYOUT_CONFIG)
    return DEFAULT_AUTO_PAYOUT_CONFIG

def save_auto_payout_config(enabled: bool, min_limit: float) -> tuple:
    """Salva a configuração do Robô de Saque Automático no Firebase."""
    payload = {
        "enabled": bool(enabled),
        "min_limit": max(1.00, float(min_limit))
    }
    status, _ = _firebase_req("app_config/auto_payout", method="PUT", data=payload)
    if status in (200, 201):
        st_str = "ATIVADO" if enabled else "DESATIVADO"
        return True, f"Robô de Saque Automático {st_str} com limite mínimo de R$ {min_limit:.2f}!", payload
    return False, f"Erro ao conectar com o servidor (HTTP {status}).", None

def create_withdrawal_request(username: str, amount: float, pix_key: str, pix_type: str, description: str = "", mistic_mgr=None) -> tuple:
    """Cria uma solicitação de saque no Firebase.
    IMPORTANTE: O saldo do cliente NUNCA é deduzido preventivamente. O saldo SÓ É DEBITADO após o PIX ser efetivado com sucesso pela API ou pelo Admin!
    """
    username_clean = username.strip().lower()
    
    # 1. Verifica se o usuário possui saldo suficiente sem debitar a conta
    reserved_ok, msg, current_bal = reserve_user_balance_for_withdrawal(username_clean, amount)
    if not reserved_ok:
        return False, msg, current_bal, False

    req_id = f"req_{uuid.uuid4().hex[:10]}"
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # 2. Verifica se o Robô de Saque Automático pode processar o PIX diretamente
    auto_cfg = get_auto_payout_config()
    auto_enabled = auto_cfg.get("enabled", True)
    min_limit = float(auto_cfg.get("min_limit", 5.00))

    if auto_enabled and amount >= min_limit and mistic_mgr and mistic_mgr.is_configured():
        payload = {
            "amount": amount,
            "pixKey": pix_key,
            "pixKeyType": pix_type,
            "description": f"Saque Auto - {username_clean}"
        }
        headers = mistic_mgr.get_headers()
        api_status, data = mistic_mgr._make_request_raw(f"{mistic_mgr.base_url}/transactions/withdraw", method="POST", headers=headers, body=payload)

        if api_status in (200, 201, 202):
            tx_info = data.get("data", {}) if isinstance(data, dict) else {}
            out_id = str(tx_info.get("transactionId") or tx_info.get("jobId") or f"out_auto_{req_id}")

            req_payload = {
                "id": req_id,
                "username": username_clean,
                "amount": amount,
                "pix_key": pix_key,
                "pix_type": pix_type,
                "description": description or "Saque Automático via Robô",
                "status": "ENVIADO_PENDENTE_API",
                "api_tx_id": out_id,
                "created_at": now_str,
                "updated_at": now_str
            }
            _firebase_req(f"withdrawal_requests/{req_id}", method="PUT", data=req_payload)

            return True, f"⚡ SAQUE AUTOMÁTICO SOLICITADO! O Robô enviou R$ {amount:.2f} via PIX e está aguardando confirmação da rede.", current_bal, True, out_id, req_id
        else:
            # Se a API falhou, o saldo do usuário PERMANECE INTACTO
            err_msg = data.get("message") if isinstance(data, dict) else data.get("error") if isinstance(data, dict) else str(data)
            return False, f"Falha na API da Rede ({api_status}): {err_msg}. O seu saldo permaneceu intacto.", current_bal, False, None, None

    # 4. Se não for automático, envia para a fila de aprovação manual do Admin SEM debitar o saldo do cliente
    payload = {
        "id": req_id,
        "username": username_clean,
        "amount": amount,
        "pix_key": pix_key,
        "pix_type": pix_type,
        "description": description or "Solicitação de Saque",
        "status": "PENDENTE_APROVACAO",
        "created_at": now_str,
        "updated_at": now_str
    }

    status, resp = _firebase_req(f"withdrawal_requests/{req_id}", method="PUT", data=payload)
    if status in (200, 201):
        return True, f"Solicitação de saque #{req_id} enviada com sucesso! Aguarde a aprovação do administrador.", current_bal, False
    else:
        return False, "Erro de rede ao salvar solicitação. Tente novamente.", current_bal, False

def get_pending_withdrawals() -> list:
    """Obtém todas as solicitações de saque pendentes de aprovação pelo Administrador."""
    status, reqs_dict = _firebase_req("withdrawal_requests", method="GET")
    if status != 200 or not reqs_dict:
        return []

    pending = []
    for req_id, data in reqs_dict.items():
        if isinstance(data, dict) and data.get("status") == "PENDENTE_APROVACAO":
            pending.append(data)
    
    pending.sort(key=lambda x: x.get("created_at", ""), reverse=True)
    return pending

def get_user_withdrawals(username: str) -> list:
    """Obtém o histórico de saques do usuário."""
    username_clean = username.strip().lower()
    status, reqs_dict = _firebase_req("withdrawal_requests", method="GET")
    if status != 200 or not reqs_dict:
        return []

    user_reqs = []
    for req_id, data in reqs_dict.items():
        if isinstance(data, dict) and data.get("username") == username_clean:
            user_reqs.append(data)
    
    user_reqs.sort(key=lambda x: x.get("created_at", ""), reverse=True)
    return user_reqs

def approve_withdrawal_request(req_id: str, mistic_mgr) -> tuple:
    """Aprova a solicitação de saque no Firebase e executa o pagamento via MisticPay API.
    O saldo do usuário é debitado SOMENTE se o envio do PIX for concluído com sucesso.
    """
    status, req_data = _firebase_req(f"withdrawal_requests/{req_id}", method="GET")
    if status != 200 or not req_data:
        return False, "Solicitação de saque não encontrada."

    if req_data.get("status") != "PENDENTE_APROVACAO":
        return False, f"Esta solicitação já foi processada (Status: {req_data.get('status')})."

    amount = float(req_data.get("amount", 0.0))
    pix_key = req_data.get("pix_key", "")
    pix_type = req_data.get("pix_type", "CPF")
    username = req_data.get("username", "")

    # Re-verifica se o usuário possui saldo suficiente no momento da aprovação
    current_bal = get_user_balance_from_firebase(username)
    if amount > current_bal:
        _firebase_req(f"withdrawal_requests/{req_id}/status", method="PUT", data="RECUSADO_SALDO_INSUFICIENTE")
        return False, f"O usuário {username} não possui saldo suficiente para aprovar este saque (Saldo Atual: R$ {current_bal:.2f})."

    payload = {
        "amount": amount,
        "pixKey": pix_key,
        "pixKeyType": pix_type,
        "description": f"Saque Aprovado - {username}"
    }

    headers = mistic_mgr.get_headers()
    api_status, data = mistic_mgr._make_request_raw(f"{mistic_mgr.base_url}/transactions/withdraw", method="POST", headers=headers, body=payload)

    if api_status in (200, 201, 202):
        now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        tx_info = data.get("data", {})
        tx_id = str(tx_info.get("transactionId") or tx_info.get("jobId") or "api_success")

        # SOMENTE APÓS O SUCESSO DA API: Debita o saldo do cliente
        deduct_ok, deduct_msg, new_bal = deduct_user_balance_in_firebase(username, amount)

        _firebase_req(f"withdrawal_requests/{req_id}/status", method="PUT", data="APROVADO_E_ENVIADO")
        _firebase_req(f"withdrawal_requests/{req_id}/api_tx_id", method="PUT", data=tx_id)
        _firebase_req(f"withdrawal_requests/{req_id}/approved_at", method="PUT", data=now_str)

        return True, f"Saque #{req_id} APROVADO com sucesso! PIX enviado (ID: {tx_id}). Novo saldo do cliente: R$ {new_bal:.2f}."
    else:
        err_msg = data.get("message") or data.get("error") or str(data)
        return False, f"Falha na API da MisticPay ({api_status}): {err_msg}. O saldo do cliente não foi debitado."

def reject_withdrawal_request(req_id: str, reason: str = "Recusado pelo administrador") -> tuple:
    """Recusa a solicitação de saque no Firebase."""
    status, req_data = _firebase_req(f"withdrawal_requests/{req_id}", method="GET")
    if status != 200 or not req_data:
        return False, "Solicitação de saque não encontrada."

    if req_data.get("status") != "PENDENTE_APROVACAO":
        return False, f"Esta solicitação já foi processada (Status: {req_data.get('status')})."

    amount = float(req_data.get("amount", 0.0))
    username = req_data.get("username", "")

    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    _firebase_req(f"withdrawal_requests/{req_id}/status", method="PUT", data="RECUSADO")
    _firebase_req(f"withdrawal_requests/{req_id}/rejection_reason", method="PUT", data=reason)
    _firebase_req(f"withdrawal_requests/{req_id}/rejected_at", method="PUT", data=now_str)

    current_bal = get_user_balance_from_firebase(username)

    return True, f"Solicitação #{req_id} RECUSADA. O saldo do usuário {username} permaneceu intacto (R$ {current_bal:.2f})."
