import os
from core.ui import Colors, print_header, print_status, prompt_input, pause

def run_customization_menu():
    """Menu para personalização e integração do Termux."""
    while True:
        print_header("Termux - Personalização & Integração Android")
        print("Escolha uma opção de personalização:\n")
        print(f"  [{Colors.BRIGHT_GREEN}1{Colors.RESET}] Configurar Acesso ao Armazenamento (termux-setup-storage)")
        print(f"  [{Colors.BRIGHT_GREEN}2{Colors.RESET}] Instalar Oh-My-Zsh + Tema Zsh")
        print(f"  [{Colors.BRIGHT_GREEN}3{Colors.RESET}] Testar Termux-API (Vibrar, Notificação, Toast)")
        print(f"  [{Colors.BRIGHT_GREEN}4{Colors.RESET}] Definir Termux Master Hub no Login (.bashrc / .zshrc)")
        print(f"  [{Colors.BRIGHT_RED}0{Colors.RESET}] Voltar ao Menu Principal")

        choice = prompt_input("\nOpção", default="0")

        if choice == "0":
            break
        elif choice == "1":
            print_status("Solicitando permissão de armazenamento no Android...", "info")
            os.system("termux-setup-storage")
            print_status("Permissão solicitada! Confirme no prompt da tela se aparecer.", "success")
            pause()
        elif choice == "2":
            print_status("Instalando Oh-My-Zsh via script oficial...", "info")
            cmd = 'sh -c "$(curl -fsSL https://raw.githubusercontent.com/ohmyzsh/ohmyzsh/master/tools/install.sh)" "" --unattended'
            os.system(cmd)
            print_status("Oh-My-Zsh instalado com sucesso!", "success")
            pause()
        elif choice == "3":
            _test_termux_api()
        elif choice == "4":
            _configure_autostart()
        else:
            print_status("Opção inválida.", "error")

def _test_termux_api():
    print_header("Testar Recursos do Termux-API")
    print("1. Enviar mensagem Toast na tela")
    print("2. Vibrar dispositivo")
    print("3. Exibir Notificação")
    
    sub = prompt_input("Escolha", default="1")
    if sub == "1":
        msg = prompt_input("Mensagem", default="Olá do Termux Master Hub!")
        os.system(f'termux-toast -s "{msg}"')
    elif sub == "2":
        os.system('termux-vibrate -d 500')
    elif sub == "3":
        os.system('termux-notification -t "Termux Master" -c "Sistema ativo"')
    print_status("Comando executado!", "success")
    pause()

def _configure_autostart():
    print_header("Configurar Autostart no Termux")
    print("Deseja que o Termux Master Hub abra automaticamente sempre que iniciar o Termux?")
    res = prompt_input("Ativar inicialização automática? (S/N)", default="S").upper()
    
    home_dir = os.path.expanduser("~")
    bashrc_path = os.path.join(home_dir, ".bashrc")
    zshrc_path = os.path.join(home_dir, ".zshrc")
    
    script_entry = "\n# Termux Master Hub Autostart\nif [ -f ~/Termux/main.py ]; then\n  python ~/Termux/main.py\nfi\n"
    
    if res == "S":
        for path in [bashrc_path, zshrc_path]:
            try:
                content = ""
                if os.path.exists(path):
                    with open(path, "r", encoding="utf-8") as f:
                        content = f.read()
                if "# Termux Master Hub Autostart" not in content:
                    with open(path, "a", encoding="utf-8") as f:
                        f.write(script_entry)
            except Exception:
                pass
        print_status("Autostart configurado no .bashrc e .zshrc!", "success")
    else:
        print_status("Configuração mantida. Você pode abrir manualmente via 'python main.py' ou 'tmenu'.", "info")
    pause()
