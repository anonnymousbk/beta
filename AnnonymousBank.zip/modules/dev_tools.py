import os
import socket
import subprocess
from core.ui import Colors, print_header, print_status, prompt_input, pause, print_box

def run_dev_tools():
    """Menu para ferramentas rápidas de desenvolvimento."""
    while True:
        print_header("Termux - Ferramentas de Desenvolvedor")
        print(f"  [{Colors.BRIGHT_GREEN}1{Colors.RESET}] Iniciar Servidor Web HTTP Rápido (Python http.server)")
        print(f"  [{Colors.BRIGHT_GREEN}2{Colors.RESET}] Diagnóstico de Rede & Testar Porta")
        print(f"  [{Colors.BRIGHT_GREEN}3{Colors.RESET}] Assistente Git (Clonar / Status / Pull)")
        print(f"  [{Colors.BRIGHT_RED}0{Colors.RESET}] Voltar ao Menu Principal")

        choice = prompt_input("\nOpção", default="0")

        if choice == "0":
            break
        elif choice == "1":
            _start_http_server()
        elif choice == "2":
            _network_diagnostic()
        elif choice == "3":
            _git_helper()
        else:
            print_status("Opção inválida.", "error")

def _start_http_server():
    print_header("Servidor Web HTTP Rápido")
    port = prompt_input("Informe a Porta HTTP", default="8080")
    folder = prompt_input("Diretório para servir", default=".")
    
    print_status(f"Servidor HTTP iniciado em http://localhost:{port}", "success")
    print_status("Pressione CTRL+C no terminal para encerrar o servidor.", "warning")
    pause()
    os.system(f"python3 -m http.server {port} --directory {folder}")

def _network_diagnostic():
    print_header("Diagnóstico de Rede")
    host = prompt_input("Informe o host/IP para teste", default="google.com")
    port_str = prompt_input("Porta para testar conexão", default="80")
    
    try:
        port = int(port_str)
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(3)
        res = sock.connect_ex((host, port))
        sock.close()
        
        if res == 0:
            print_status(f"Porta {port} em {host} está ABERTA e acessível!", "success")
        else:
            print_status(f"Porta {port} em {host} está FECHADA ou inacessível (Código: {res}).", "error")
    except Exception as e:
        print_status(f"Erro ao testar rede: {e}", "error")
    pause()

def _git_helper():
    print_header("Assistente Git")
    print("1. Clonar Repositório (git clone)")
    print("2. Ver Status (git status)")
    print("3. Atualizar Código (git pull)")
    
    sub = prompt_input("Opção", default="2")
    if sub == "1":
        repo_url = prompt_input("URL do Repositório Git")
        if repo_url:
            os.system(f"git clone {repo_url}")
    elif sub == "2":
        os.system("git status")
    elif sub == "3":
        os.system("git pull")
    pause()
