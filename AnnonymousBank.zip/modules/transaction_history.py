import json
import urllib.parse
from core.ui import Colors, print_header, print_status, print_box, prompt_input, pause
from core.db import search_transactions, get_transaction_by_id, delete_transaction_by_id, clear_all_transactions
from modules.misticpay import _make_request

def run_history_menu(mistic_mgr=None):
    """Submenu completo de histórico e buscas (Banco Local SQLite + Servidor da Rede)."""
    while True:
        print_header("Histórico & Consultas de Transações")
        
        print(f"  [{Colors.BRIGHT_GREEN}1{Colors.RESET}] 📋 Listar Transações (Banco Local)")
        print(f"  [{Colors.BRIGHT_CYAN}2{Colors.RESET}] 🔍 Busca Avançada Local (Nome, CPF, ID, Status)")
        print(f"  [{Colors.BRIGHT_YELLOW}3{Colors.RESET}] 🌐 Consultar Transação Direto no Servidor (por ID)")
        print(f"  [{Colors.BRIGHT_MAGENTA}4{Colors.RESET}] 🚨 Consultar Infrações & MEDs no Servidor")
        print(f"  [{Colors.BRIGHT_WHITE}5{Colors.RESET}] 📄 Ver Detalhes Completos por ID")
        print(f"  [{Colors.BRIGHT_RED}6{Colors.RESET}] 🗑️ Excluir Registro do Banco Local")
        print(f"  [{Colors.BRIGHT_RED}7{Colors.RESET}] 🧹 Limpar Histórico Local")
        print(f"  [{Colors.BRIGHT_WHITE}0{Colors.RESET}] ⬅️ Voltar ao Menu Principal")

        choice = prompt_input("\nOpção", default="1")

        if choice == "0":
            break
        elif choice == "1":
            _list_all_transactions()
        elif choice == "2":
            _advanced_search()
        elif choice == "3":
            _search_misticpay_api(mistic_mgr)
        elif choice == "4":
            _list_meds_misticpay(mistic_mgr)
        elif choice == "5":
            _view_details()
        elif choice == "6":
            _delete_single()
        elif choice == "7":
            _clear_all()
        else:
            print_status("Opção inválida.", "error")

def _render_tx_list(tx_list: list):
    if not tx_list:
        print_status("Nenhuma transação encontrada no banco local.", "warning")
        return

    print(f"\n Total Encontrado: {Colors.BOLD}{len(tx_list)}{Colors.RESET}\n")
    print(f" {'ID':<15} | {'TIPO':<8} | {'VALOR':<10} | {'PAGADOR / CHAVE':<18} | {'STATUS'}")
    print(" ─" * 70)

    for tx in tx_list:
        tx_id = str(tx['id'])[:14]
        tx_type = "RECEBER" if tx['tx_type'] == 'CASHIN' else "ENVIAR"
        type_color = Colors.BRIGHT_GREEN if tx['tx_type'] == 'CASHIN' else Colors.BRIGHT_YELLOW
        val = f"R$ {tx['amount']:.2f}"
        target = (tx.get('payer_name') or tx.get('pix_key') or "N/A")[:17]
        st = tx.get('status', 'PENDENTE')
        st_color = Colors.BRIGHT_GREEN if st == 'COMPLETO' else Colors.BRIGHT_YELLOW

        print(f" {tx_id:<15} | {type_color}{tx_type:<8}{Colors.RESET} | {val:<10} | {target:<18} | {st_color}{st}{Colors.RESET}")
    print(" ─" * 70)

def _list_all_transactions():
    print_header("Listagem de Transações no Banco Local")
    results = search_transactions(limit=100)
    _render_tx_list(results)
    pause()

def _advanced_search():
    print_header("Busca Avançada no Banco Local")
    print("Preencha um ou mais filtros (deixe em branco para ignorar):\n")
    
    query = prompt_input("Termo de busca (Nome, CPF, ID ou Descrição)")
    
    print("\nFiltro de Status:")
    print(" 1. COMPLETO / PAGO")
    print(" 2. PENDENTE")
    print(" 3. FALHA")
    print(" 0. Todos")
    st_opt = prompt_input("Status", default="0")
    st_map = {"1": "COMPLETO", "2": "PENDENTE", "3": "FALHA"}
    st_filter = st_map.get(st_opt, None)

    print("\nFiltro de Tipo:")
    print(" 1. Recebidos (Cash-In)")
    print(" 2. Enviados (Cash-Out)")
    print(" 0. Todos")
    tp_opt = prompt_input("Tipo", default="0")
    tp_map = {"1": "CASHIN", "2": "CASHOUT"}
    tp_filter = tp_map.get(tp_opt, None)

    results = search_transactions(query=query, status_filter=st_filter, type_filter=tp_filter, limit=100)
    _render_tx_list(results)
    pause()

def _search_misticpay_api(mistic_mgr):
    """Consulta uma transação diretamente no Servidor da Rede via POST /api/transactions/check."""
    print_header("Consulta Direta no Servidor da Rede")
    
    if not mistic_mgr or not mistic_mgr.is_configured():
        print_status("Credenciais da API não configuradas!", "warning")
        pause()
        return

    tx_id = prompt_input("Informe o ID da transação no Servidor")
    if not tx_id:
        return

    print_status("Consultando servidores da Rede...", "info")
    headers = mistic_mgr.get_headers()
    url = f"{mistic_mgr.base_url}/transactions/check"
    status_code, data = _make_request(url, method="POST", headers=headers, body={"transactionId": str(tx_id)})

    if status_code == 200:
        print_box(json.dumps(data, indent=2, ensure_ascii=False), color=Colors.BRIGHT_GREEN, title=f"Resposta Oficial da Rede ({tx_id})")
    else:
        msg = data.get("message") or data.get("error") or str(data)
        print_status(f"Consulta API falhou ({status_code}): {msg}", "error")
    pause()

def _list_meds_misticpay(mistic_mgr):
    """Consulta a lista de infrações / MEDs direto no Servidor."""
    print_header("Infrações & MEDs no Servidor")

    if not mistic_mgr or not mistic_mgr.is_configured():
        print_status("Credenciais da API não configuradas!", "warning")
        pause()
        return

    print_status("Buscando registros de infrações na Rede...", "info")
    headers = mistic_mgr.get_headers()
    url = f"{mistic_mgr.base_url}/meds/infractions/list?page=1&perPage=20"
    status_code, data = _make_request(url, method="GET", headers=headers)

    if status_code == 200:
        infractions = data.get("data", {}).get("infractions", [])
        if not infractions:
            print_status("Nenhuma infração / MED registrada para a sua conta!", "success")
        else:
            print_box(json.dumps(infractions, indent=2, ensure_ascii=False), color=Colors.BRIGHT_YELLOW, title="Lista de Infrações MED")
    else:
        msg = data.get("message") or data.get("error") or str(data)
        print_status(f"Erro na consulta de MEDs ({status_code}): {msg}", "error")
    pause()

def _view_details():
    print_header("Detalhes Completos da Transação")
    tx_id = prompt_input("Informe o ID da transação no banco local")
    if not tx_id:
        return

    tx = get_transaction_by_id(tx_id)
    if not tx:
        print_status(f"Transação '{tx_id}' não encontrada no banco local.", "error")
    else:
        box_content = (
            f"📌 ID Transação:    {Colors.BOLD}{tx['id']}{Colors.RESET}\n"
            f"🏷️ ID Cliente:      {tx.get('client_tx_id', 'N/A')}\n"
            f"📊 Tipo:            {'RECEBIMENTO (CASH-IN)' if tx['tx_type'] == 'CASHIN' else 'SAQUE (CASH-OUT)'}\n"
            f"💵 Valor:           {Colors.BRIGHT_GREEN}R$ {tx['amount']:.2f}{Colors.RESET}\n"
            f"👤 Nome Pagador:    {tx.get('payer_name', 'N/A')}\n"
            f"🪪 CPF/CNPJ:        {tx.get('payer_doc', 'N/A')}\n"
            f"🔑 Chave PIX:       {tx.get('pix_key', 'N/A')} ({tx.get('pix_type', 'N/A')})\n"
            f"📝 Descrição:       {tx.get('description', 'N/A')}\n"
            f"📅 Criado em:       {tx.get('created_at', 'N/A')}\n"
            f"🔄 Atualizado em:   {tx.get('updated_at', 'N/A')}\n"
            f"✅ Status Atual:    {Colors.BRIGHT_GREEN if tx['status'] == 'COMPLETO' else Colors.BRIGHT_YELLOW}{tx['status']}{Colors.RESET}"
        )
        print_box(box_content, color=Colors.BRIGHT_CYAN, title=f"Ficha Completa {tx['id']}")
    pause()

def _delete_single():
    print_header("Excluir Transação do Banco Local")
    tx_id = prompt_input("Informe o ID da transação a ser excluída")
    if not tx_id:
        return

    tx = get_transaction_by_id(tx_id)
    if not tx:
        print_status(f"Transação '{tx_id}' não encontrada no banco.", "error")
        pause()
        return

    print(f"\n{Colors.BRIGHT_RED}⚠️ ATENÇÃO: Esta ação removerá a transação do histórico local.{Colors.RESET}")
    confirm = prompt_input("Confirmar exclusão? (digite 'SIM')", default="NAO").upper()

    if confirm == "SIM":
        res = delete_transaction_by_id(tx_id)
        if res:
            print_status("Transação excluída do banco de dados com sucesso!", "success")
        else:
            print_status("Falha ao excluir a transação.", "error")
    else:
        print_status("Exclusão cancelada.", "warning")
    pause()

def _clear_all():
    print_header("Limpar Todo o Histórico Local")
    print(f"\n{Colors.BRIGHT_RED}⚠️ ATENÇÃO EXTREMA: Isso apagará TODAS as transações salvas no banco local.{Colors.RESET}")
    confirm = prompt_input("Tem certeza? (digite 'DELETAR TUDO')", default="NAO").upper()

    if confirm == "DELETAR TUDO":
        cnt = clear_all_transactions()
        print_status(f"Banco de dados limpo! ({cnt} registros apagados).", "success")
    else:
        print_status("Operação cancelada.", "warning")
    pause()
