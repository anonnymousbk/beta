import json
import os
from core.ui import Colors, print_header, print_status, prompt_input, pause

def run_custom_actions(config, config_path: str):
    """Executa e gerencia atalhos customizados do usuário salvos no config.json."""
    while True:
        print_header("Termux - Atalhos Customizados do Usuário")
        custom_list = config.get("custom_commands", [])

        if not custom_list:
            print_status("Nenhum atalho customizado cadastrado.", "info")
        else:
            for idx, item in enumerate(custom_list, start=1):
                name = item.get("name", "Sem Nome")
                cmd = item.get("command", "")
                print(f"  [{Colors.BRIGHT_GREEN}{idx}{Colors.RESET}] {Colors.BOLD}{name}{Colors.RESET} ({Colors.DIM}{cmd}{Colors.RESET})")

        print(f"\n  [{Colors.BRIGHT_CYAN}A{Colors.RESET}] Adicionar Novo Atalho")
        print(f"  [{Colors.BRIGHT_RED}0{Colors.RESET}] Voltar ao Menu Principal")

        choice = prompt_input("\nOpção", default="0").upper()

        if choice == "0":
            break
        elif choice == "A":
            new_name = prompt_input("Nome para o atalho")
            new_cmd = prompt_input("Comando Shell a executar")
            if new_name and new_cmd:
                custom_list.append({"name": new_name, "command": new_cmd})
                config["custom_commands"] = custom_list
                try:
                    with open(config_path, "w", encoding="utf-8") as f:
                        json.dump(config, f, indent=2, ensure_ascii=False)
                    print_status("Atalho salvo com sucesso!", "success")
                except Exception as e:
                    print_status(f"Erro ao salvar config: {e}", "error")
            pause()
        else:
            try:
                idx_val = int(choice) - 1
                if 0 <= idx_val < len(custom_list):
                    target = custom_list[idx_val]
                    cmd_str = target.get("command", "")
                    print_status(f"Executando: {cmd_str}", "info")
                    os.system(cmd_str)
                    pause()
                else:
                    print_status("Opção inválida.", "error")
            except ValueError:
                print_status("Opção inválida.", "error")
