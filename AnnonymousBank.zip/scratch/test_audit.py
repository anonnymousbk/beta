import sys
import os

if hasattr(sys.stdout, 'reconfigure'):
    try:
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    except Exception:
        pass

BASE_DIR = os.path.dirname(os.path.realpath(__file__))
sys.path.insert(0, os.path.dirname(BASE_DIR))

from core.updater import (
    publish_update_to_firebase,
    get_active_update_info,
    get_update_user_statistics,
    delete_active_update_from_firebase
)
from core.auth import (
    register_user_in_firebase,
    delete_user_from_firebase,
    update_user_version_in_firebase
)

print("====================================================")
print(" 🔍 AUDITORIA E VARREDURA COMPLETA DO SISTEMA (CHECKAP)")
print("====================================================")

print("[TEST 1] Publicação de Atualização OTA...")
ok_pub, msg_pub = publish_update_to_firebase('6.6.0', 'https://pixeldrain.com/u/test12345', 'Notas de Teste')
assert ok_pub, 'Publish update failed'
active_info = get_active_update_info()
assert active_info and active_info.get('version') == '6.6.0', 'Active info mismatch'
print("  Publicação OTA: 100% OK!")

print("[TEST 2] Rastreamento de Versão & Estatísticas de Clientes...")
register_user_in_firebase('user_upd_test', 'pass', 30, 'DIAS')
update_user_version_in_firebase('user_upd_test', '6.6.0')

register_user_in_firebase('user_old_test', 'pass', 30, 'DIAS')
update_user_version_in_firebase('user_old_test', '6.0.0')

stats = get_update_user_statistics()
t_ver = stats.get('target_version')
upd_cnt = stats.get('updated_count')
outd_cnt = stats.get('outdated_count')

assert upd_cnt >= 1, 'Updated count check failed'
assert outd_cnt >= 1, 'Outdated count check failed'
print(f"  Versão Alvo: v{t_ver} | Atualizados: {upd_cnt} | Desatualizados: {outd_cnt}")
print("  Estatísticas de Atualização: 100% OK!")

print("[TEST 3] Remoção / Exclusão de Atualização Ativa...")
ok_del, msg_del = delete_active_update_from_firebase()
assert ok_del, 'Delete update failed'
assert get_active_update_info() == None, 'Update info should be deleted'
print("  Remoção de Atualização: 100% OK!")

print("[TEST 4] Limpeza de usuários de teste...")
delete_user_from_firebase('user_upd_test')
delete_user_from_firebase('user_old_test')

print("\n====================================================")
print(" 🎉 AUDITORIA E VARREDURA CONCLUÍDAS COM 100% DE SUCESSO!")
print("====================================================")
