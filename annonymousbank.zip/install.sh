#!/data/data/com.termux/files/usr/bin/bash

echo -e "\033[1;36m====================================================\033[0m"
echo -e "\033[1;32m         ANNONYMOUS BANK PIX SYSTEM v6.5            \033[0m"
echo -e "\033[1;36m====================================================\033[0m"
echo ""

echo -e "\033[1;33m[1/3] Instalando dependências e bibliotecas Python no Termux...\033[0m"
pkg update -y && pkg install -y python python-pip curl termux-api
pip install qrcode colorama

echo -e "\033[1;33m[2/3] Verificando e compilando código para a versão Python do Termux...\033[0m"

# Se houver arquivos fonte .py, compila nativamente no Termux para garantir compatibilidade total de Bytecode Magic Number
if [ -f "compile_project.py" ] && [ -f "main.py" ]; then
    echo -e "\033[1;36mCompilando bytecode nativo para Python $(python -V)... \033[0m"
    python compile_project.py
fi

if [ -f "dist_protected/main.pyc" ]; then
    TARGET_DIR="$(pwd)/dist_protected"
    SCRIPT_FILE="main.pyc"
elif [ -f "main.pyc" ]; then
    TARGET_DIR="$(pwd)"
    SCRIPT_FILE="main.pyc"
else
    TARGET_DIR="$(pwd)"
    SCRIPT_FILE="main.py"
fi

echo -e "\033[1;33m[3/3] Registrando executáveis globais no Termux...\033[0m"
for BIN_NAME in "anon" "bank" "anonbank" "anonymous-bank" "tmenu"; do
    TERMUX_BIN="$PREFIX/bin/$BIN_NAME"
    cat <<EOF > "$TERMUX_BIN"
#!/data/data/com.termux/files/usr/bin/sh
cd "$TARGET_DIR"
python "$SCRIPT_FILE" "\$@"
EOF
    chmod +x "$TERMUX_BIN"
done

# Adiciona alias no .bashrc e .zshrc para rodar em qualquer aba
for RC_FILE in "$HOME/.bashrc" "$HOME/.zshrc"; do
    if [ -f "$RC_FILE" ]; then
        for ALIAS_NAME in "anon" "bank" "anonbank"; do
            if ! grep -q "alias $ALIAS_NAME=" "$RC_FILE"; then
                echo "alias $ALIAS_NAME='cd $TARGET_DIR && python $SCRIPT_FILE'" >> "$RC_FILE"
            fi
        done
    fi
done

echo ""
echo -e "\033[1;32m====================================================\033[0m"
echo -e "\033[1;32m ✔ INSTALAÇÃO CONCLUÍDA COM SUCESSO!                 \033[0m"
echo -e "\033[1;32m====================================================\033[0m"
echo -e "\033[1;37mVocê pode abrir o aplicativo em QUALQUER aba ou pasta digitando:\033[0m"
echo -e "\033[1;36m  anon \033[0m  ou  \033[1;36m bank \033[0m  ou  \033[1;36m anonbank \033[0m"
echo ""
