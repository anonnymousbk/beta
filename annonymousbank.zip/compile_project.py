#!/usr/bin/env python3
import os
import sys
import shutil
import subprocess

# Garante suporte a UTF-8 no stdout
if hasattr(sys.stdout, 'reconfigure'):
    try:
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    except Exception:
        pass

BASE_DIR = os.path.dirname(os.path.realpath(__file__))
DIST_DIR = os.path.join(BASE_DIR, "dist_protected")
DIST_CLIENT_DIR = os.path.join(BASE_DIR, "dist_client_protected")

def build_compiled_distribution():
    """Gera a versão compilada nativamente (Cython) para a plataforma atual.
    Gera duas pastas:
    - dist_protected: Versão Master Completa (com admin_tools nativo).
    - dist_client_protected: Versão Clientes (sem o painel admin_tools nativo).
    """
    print("====================================================")
    print(f"   COMPILADOR CYTHON NATIVO ULTRA-SEGURO v6.9 (Python {sys.version.split()[0]})   ")
    print("====================================================")
    
    try:
        import Cython
    except ImportError:
        print("Erro: Cython não está instalado!")
        print("Instale executando: pip install cython setuptools")
        sys.exit(1)

    print("\n[1/5] Preparando estrutura de compilação protegida...")
    for d in (DIST_DIR, DIST_CLIENT_DIR):
        if os.path.exists(d):
            try:
                shutil.rmtree(d)
            except Exception:
                pass

    os.makedirs(DIST_DIR, exist_ok=True)
    # Copia todo o projeto para a pasta de distribuição Master
    shutil.copytree(BASE_DIR, DIST_DIR, dirs_exist_ok=True, ignore=shutil.ignore_patterns("dist_protected", "dist_client_protected", "*.pyc", "__pycache__", ".git", "build"))

    print("[2/5] Identificando arquivos para ofuscação nativa...")
    py_files_to_compile = []
    
    # Não vamos compilar o main.py para que ele sirva de ponto de entrada limpo (python main.py)
    # Mas todo o coração do sistema (core, modules, admin_tools) será convertido em binário C
    exclude_files = ["main.py", "compile_project.py"]
    
    for root, dirs, files in os.walk(DIST_DIR):
        for f in files:
            if f.endswith(".py") and f not in exclude_files:
                py_files_to_compile.append(os.path.join(root, f))
    
    print(f"      Encontrados {len(py_files_to_compile)} módulos críticos para compilação.")

    print("\n[3/5] Traduzindo Python para Linguagem C e compilando para Binário (Shared Object)...")
    print("      Isso pode demorar um pouco (dependendo do processador). Aguarde...")
    
    # Cria um script setup.py temporário na pasta DIST_DIR
    setup_path = os.path.join(DIST_DIR, "setup_compile.py")
    with open(setup_path, "w", encoding="utf-8") as f:
        f.write(f"""
from setuptools import setup, Extension
from Cython.Build import cythonize
import os

ext_modules = []
def get_ext_paths():
    paths = []
    for root, dirs, files in os.walk("."):
        for f in files:
            if f.endswith(".py") and f not in {exclude_files} and f != "setup_compile.py":
                filepath = os.path.join(root, f)
                # Converte caminho de arquivo para sintaxe de módulo (ex: core.auth)
                mod_name = os.path.splitext(os.path.relpath(filepath, "."))[0].replace(os.path.sep, ".")
                ext_modules.append(Extension(mod_name, [filepath]))
    return ext_modules

setup(
    ext_modules=cythonize(get_ext_paths(), compiler_directives={{'language_level': "3", 'always_allow_keywords': True}}, quiet=True),
    script_args=["build_ext", "--inplace"]
)
""")
    
    # Roda o setup.py em subprocesso na pasta DIST_DIR
    try:
        subprocess.check_call([sys.executable, "setup_compile.py"], cwd=DIST_DIR, stdout=subprocess.DEVNULL)
    except subprocess.CalledProcessError as e:
        print("\n[ERRO CRÍTICO] Falha ao compilar nativamente. Verifique se o compilador C (clang/gcc) está instalado no Termux.")
        print("Tente rodar: pkg install clang python")
        sys.exit(1)

    print("\n[4/5] Removendo código-fonte (.py e .c) para proteção total contra engenharia reversa...")
    removed_count = 0
    for root, dirs, files in os.walk(DIST_DIR):
        for f in files:
            if f == "setup_compile.py" or (f.endswith(".c") and not f.endswith(".json")):
                os.remove(os.path.join(root, f))
            elif f.endswith(".py") and f not in exclude_files:
                os.remove(os.path.join(root, f))
                removed_count += 1
                
    # Remove a pasta 'build' temporária do cython
    build_tmp = os.path.join(DIST_DIR, "build")
    if os.path.exists(build_tmp):
        shutil.rmtree(build_tmp)

    # Cria a cópia limpa para Clientes sem o binário admin_tools
    print("[5/5] Gerando pacote exclusivo para Clientes ('dist_client_protected')...")
    shutil.copytree(DIST_DIR, DIST_CLIENT_DIR, dirs_exist_ok=True)
    
    # Remove qualquer traço do admin_tools no cliente
    for f in os.listdir(DIST_CLIENT_DIR):
        if f.startswith("admin_tools."):
            os.remove(os.path.join(DIST_CLIENT_DIR, f))

    print("\n====================================================")
    print(" [OK] COMPILAÇÃO NATIVA (CYTHON) CONCLUÍDA COM SUCESSO!")
    print("====================================================")
    print(f"Foram transformados {removed_count} arquivos Python em Binários Nativos (.so / .pyd).")
    print(f"\n📂 Pastas Geradas:")
    print(f"  1. Master Completo: {DIST_DIR} (Com Painel Admin Nativo)")
    print(f"  2. Versão Clientes:  {DIST_CLIENT_DIR} (Sem Painel Admin)")
    print("\nPara enviar aos clientes, copie todo o conteúdo da pasta 'dist_client_protected'.")
    print("Para iniciar, o cliente apenas rodará: python main.py")
    print("====================================================")

if __name__ == "__main__":
    build_compiled_distribution()

